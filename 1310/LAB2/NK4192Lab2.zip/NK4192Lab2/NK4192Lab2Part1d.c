/******************************************************************************
 * CSE 1310 Fall 2021
 * File name: NK4192Lab2Part1d.c 
 * Author : Kili
 * Created on: 10/26/2021
.*
 * UTA Student Name: Nebojsa Kilibarda
 * UTA ID: 1001934192
*******************************************************************************/
#include <stdio.h>
#include <ctype.h>
int iscons(char ltr);
int main()
{
    printf("%c %c %c %c %c %c %c\n",'N','e','b','o','j','s','a');
    printf("%d %d %d %d %d %d %d\n",'N','e','b','o','j','s','a');
    
    printf("%3c %3c %3c %3c %3c %3c %3c\n",'N','e','b','o','j','s','a');
    printf("%3d %3d %3d %3d %3d %3d %3d\n",'N','e','b','o','j','s','a');
    
    char fName[7] = "Nebojsa";
    
        if(iscons(fName[0])==1)
        {
            printf("%c %d\n", fName[0], fName[0]);
        }    
        if(iscons(fName[1])==1)
        {
            printf("%c %d\n", fName[1], fName[1]);
        }
        if(iscons(fName[2])==1)
        {
            printf("%c %d\n", fName[2], fName[2]);
        }
        if(iscons(fName[3])==1)
        {
            printf("%c %d\n", fName[3], fName[3]);
        }

        if(iscons(fName[4])==1)
        {
            printf("%c %d\n", fName[4], fName[4]);
        }

        if(iscons(fName[5])==1)
        {
            printf("%c %d\n", fName[5], fName[5]);
        }
        if(iscons(fName[6])==1)
        {
            printf("%c %d\n", fName[6], fName[6]);
        }
        
    return 0;
}
//  tests whether ltr is a consonant in the English alphabet
int iscons(char ltr)
{
    ltr = tolower(ltr);
    if ((ltr == 'a') || (ltr == 'e') ||  (ltr == 'i') 
        ||  (ltr == 'o') ||  (ltr == 'u'))
        return 0;
    return 1;
}



