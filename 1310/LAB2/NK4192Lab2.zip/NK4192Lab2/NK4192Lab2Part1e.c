/******************************************************************************
 * CSE 1310 Fall 2021
 * File name: NK4192Lab2Part1e.c 
 * Author : Kili
 * Created on: 10/26/2021
.*
 * UTA Student Name: Nebojsa Kilibarda
 * UTA ID: 1001934192
*******************************************************************************/
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int iscons(char ltr);

/****************************
 printing names and their ASCII values
 from a text file into
 formatted rows and columns
 **************************/
int main()
{
    char fName[15];
    FILE * fp;
    fp = fopen("names.txt", "r");
    
    if(fp == NULL)
        printf("Error! Could not open the requested file.\n");
    while( !feof(fp) )
    {
    fgets(fName, 15 , fp);
    printf("\nThe name on the current line of the file is %s\n\n", fName); //Printing the name string
    
    for(int k=0; k<strlen(fName) ;k++)                                   //For loop to create a formatted character row
        {
        printf("%4c", fName[k]);
        }
    printf("\n");
    
    for(int l=0; l<strlen(fName); l++)
        {
            fName[l] == '\n' ? printf("\n") : printf("%4d", fName[l]);  //If the current character is \n don't print it's ASCII value.
        }
    printf("\n\n");
        
    for(int i=0; i<strlen(fName); i++)
        {
        if(iscons(fName[i])==1 && fName[i] != '\n' && fName[i] != ' ')  // Consonant test only excludes wovels - newline, spaces and dashes are considered true
                                                                           // The for loop excludes the '\n' and ' ' from printing ASCII value to achieve desired output
            printf("%c %d\n", fName[i], fName[i]);
        }    
    }
        
    return 0;
}
//  tests whether ltr is not a vowel in the English alphabet
int iscons(char ltr)
{
    ltr = tolower(ltr);
    if ((ltr == 'a') || (ltr == 'e') ||  (ltr == 'i') 
        ||  (ltr == 'o') ||  (ltr == 'u'))
        return 0;
    return 1;
}
